// Mobile Menu
function manageMenu() {
    var menu = document.getElementById('menu');
    var openBtn = document.getElementById('openBtn');

    if (menu.style.display === 'none' || menu.style.display === '') {
        menu.style.display = 'block';
        openBtn.style.display = 'none';
    } else {
        menu.style.display = '';
        openBtn.style.display = ''; // This line is modified
    }
}


// Dark Mode
document.addEventListener('DOMContentLoaded', function () {
    const button = document.getElementById('modeToggle');
    const body = document.body;

    button.addEventListener('click', function () {
        body.classList.toggle('light-mode');
        button.innerHTML = body.classList.contains('light-mode') ? '<i class="fa-regular fa-sun"></i>' : '<i class="fa-regular fa-moon"></i>';
    });
});
